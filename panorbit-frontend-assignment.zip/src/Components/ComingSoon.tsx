import { FC } from "react";
import "../Styles/ComingSoon.css";

const ComingSoon: FC = () => {
  return <div className="coming-soon-text">Coming Soon</div>;
};

export default ComingSoon;
